package com.example.calculator

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.math.BigDecimal

data class CalculationHistoryItem(
    val id: Long = System.nanoTime(),
    val expression: String,
    val result: String,
    val digitCount: Int
)

data class CalculatorUiState(
    val rawExpression: String = "",
    val formattedExpression: String = "0",
    val previewResult: String = "",
    val finalResult: String? = null,
    val errorMessage: String? = null,
    val currentMaxDigits: Int = 0,
    val resultDigitsCount: Int = 0,
    val history: List<CalculationHistoryItem> = emptyList(),
    val showScientificRow: Boolean = true
)

class CalculatorViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(CalculatorUiState())
    val uiState: StateFlow<CalculatorUiState> = _uiState.asStateFlow()

    fun appendToken(token: String) {
        _uiState.update { state ->
            val base = if (state.finalResult != null && state.errorMessage == null) {
                // If user taps an operator right after '=', continue with result
                if (token in listOf("+", "-", "×", "÷", "^", "%")) {
                    state.finalResult.replace(",", "")
                } else {
                    ""
                }
            } else {
                state.rawExpression
            }

            val updated = buildNewExpression(base, token)
            computeLiveState(state.copy(rawExpression = updated, finalResult = null, errorMessage = null))
        }
    }

    private fun buildNewExpression(current: String, token: String): String {
        if (token == "00") {
            return if (current.isEmpty()) "0" else current + "00"
        }
        if (token == ".") {
            // Prevent two dots in the same number token
            val lastToken = current.takeLastWhile { it.isDigit() || it == '.' }
            if (lastToken.contains('.')) return current
            return if (lastToken.isEmpty()) "${current}0." else "$current."
        }
        if (token in listOf("+", "×", "÷", "^")) {
            if (current.isEmpty()) return ""
            val last = current.last()
            if (last in listOf('+', '-', '×', '÷', '^')) {
                return current.dropLast(1) + token
            }
            if (last == '(') return current
        }
        if (token == "-") {
            if (current.isNotEmpty() && current.last() in listOf('+', '-')) {
                return current.dropLast(1) + "-"
            }
        }
        return current + token
    }

    fun toggleSign() {
        _uiState.update { state ->
            val target = state.finalResult?.replace(",", "") ?: state.rawExpression
            if (target.isEmpty() || target == "0") return@update state
            val toggled = if (target.startsWith("-")) {
                target.substring(1)
            } else {
                "-$target"
            }
            computeLiveState(state.copy(rawExpression = toggled, finalResult = null, errorMessage = null))
        }
    }

    fun reciprocal() {
        _uiState.update { state ->
            val expr = state.finalResult?.replace(",", "") ?: state.rawExpression
            if (expr.isEmpty()) return@update state
            val wrapped = "1÷($expr)"
            evaluateAndRecord(state.copy(rawExpression = wrapped))
        }
    }

    fun square() {
        _uiState.update { state ->
            val expr = state.finalResult?.replace(",", "") ?: state.rawExpression
            if (expr.isEmpty()) return@update state
            val wrapped = "($expr)^2"
            evaluateAndRecord(state.copy(rawExpression = wrapped))
        }
    }

    fun backspace() {
        _uiState.update { state ->
            if (state.finalResult != null) {
                return@update state.copy(
                    rawExpression = "",
                    formattedExpression = "0",
                    previewResult = "",
                    finalResult = null,
                    errorMessage = null,
                    currentMaxDigits = 0,
                    resultDigitsCount = 0
                )
            }
            if (state.rawExpression.isEmpty()) return@update state
            val updated = state.rawExpression.dropLast(1)
            computeLiveState(state.copy(rawExpression = updated, errorMessage = null))
        }
    }

    fun clearAll() {
        _uiState.update {
            it.copy(
                rawExpression = "",
                formattedExpression = "0",
                previewResult = "",
                finalResult = null,
                errorMessage = null,
                currentMaxDigits = 0,
                resultDigitsCount = 0
            )
        }
    }

    fun toggleScientificRow() {
        _uiState.update { it.copy(showScientificRow = !it.showScientificRow) }
    }

    fun evaluateFinal() {
        _uiState.update { state ->
            evaluateAndRecord(state)
        }
    }

    fun loadHistoryItem(item: CalculationHistoryItem) {
        _uiState.update { state ->
            val raw = item.result.replace(",", "")
            computeLiveState(
                state.copy(
                    rawExpression = raw,
                    finalResult = item.result,
                    errorMessage = null
                )
            )
        }
    }

    fun clearHistory() {
        _uiState.update { it.copy(history = emptyList()) }
    }

    private fun evaluateAndRecord(state: CalculatorUiState): CalculatorUiState {
        if (state.rawExpression.isBlank()) return state
        return when (val res = BigCalculatorEngine.evaluate(state.rawExpression)) {
            is BigCalculatorEngine.CalcResult.Success -> {
                val formattedExpr = BigCalculatorEngine.formatExpressionWithSeparators(state.rawExpression)
                val historyEntry = CalculationHistoryItem(
                    expression = formattedExpr,
                    result = res.formatted,
                    digitCount = res.digitCount
                )
                state.copy(
                    formattedExpression = formattedExpr,
                    finalResult = res.formatted,
                    previewResult = "",
                    errorMessage = null,
                    resultDigitsCount = res.digitCount,
                    currentMaxDigits = maxOf(
                        BigCalculatorEngine.countDigitsInExpression(state.rawExpression),
                        res.digitCount
                    ),
                    history = (listOf(historyEntry) + state.history).take(30)
                )
            }
            is BigCalculatorEngine.CalcResult.Error -> {
                state.copy(
                    errorMessage = res.message,
                    finalResult = null
                )
            }
        }
    }

    private fun computeLiveState(state: CalculatorUiState): CalculatorUiState {
        val raw = state.rawExpression
        if (raw.isEmpty()) {
            return state.copy(
                formattedExpression = "0",
                previewResult = "",
                currentMaxDigits = 0,
                resultDigitsCount = 0
            )
        }
        val formatted = BigCalculatorEngine.formatExpressionWithSeparators(raw)
        val exprDigits = BigCalculatorEngine.countDigitsInExpression(raw)
        val preview = when (val res = BigCalculatorEngine.evaluate(raw)) {
            is BigCalculatorEngine.CalcResult.Success -> {
                if (res.value.compareTo(BigDecimal.ZERO) == 0 && raw == "0") ""
                else res.formatted
            }
            is BigCalculatorEngine.CalcResult.Error -> ""
        }
        return state.copy(
            formattedExpression = formatted,
            previewResult = preview,
            currentMaxDigits = exprDigits
        )
    }
}
