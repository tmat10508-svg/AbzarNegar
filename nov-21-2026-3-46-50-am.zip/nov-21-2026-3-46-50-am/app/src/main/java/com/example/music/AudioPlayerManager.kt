package com.example.music

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AudioPlayerState(
    val activeTrack: MusicTrack? = null,
    val isBuffering: Boolean = false,
    val isPlaying: Boolean = false,
    val positionMs: Int = 0,
    val durationMs: Int = 0,
    val error: String? = null,
    val previewedTrackIds: Set<String> = emptySet()
)

class AudioPlayerManager(private val scope: CoroutineScope) {

    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null

    private val _state = MutableStateFlow(AudioPlayerState())
    val state: StateFlow<AudioPlayerState> = _state.asStateFlow()

    fun togglePlay(track: MusicTrack) {
        val current = _state.value
        if (current.activeTrack?.id == track.id) {
            val mp = mediaPlayer
            if (mp != null && !current.isBuffering) {
                if (mp.isPlaying) {
                    mp.pause()
                    _state.update { it.copy(isPlaying = false) }
                } else {
                    mp.start()
                    _state.update { it.copy(isPlaying = true) }
                    startProgressPolling()
                }
                return
            }
        }
        playTrack(track)
    }

    private fun playTrack(track: MusicTrack) {
        releasePlayer()
        _state.update {
            it.copy(
                activeTrack = track,
                isBuffering = true,
                isPlaying = false,
                positionMs = 0,
                durationMs = (track.durationSec * 1000).coerceAtLeast(1000),
                error = null
            )
        }

        try {
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(track.streamUrl)
                setOnPreparedListener { preparedMp ->
                    preparedMp.start()
                    _state.update { s ->
                        s.copy(
                            isBuffering = false,
                            isPlaying = true,
                            durationMs = preparedMp.duration.coerceAtLeast(1000),
                            previewedTrackIds = s.previewedTrackIds + track.id
                        )
                    }
                    startProgressPolling()
                }
                setOnCompletionListener {
                    _state.update { it.copy(isPlaying = false, positionMs = 0) }
                    it.seekTo(0)
                }
                setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "MediaPlayer error what=$what extra=$extra for ${track.streamUrl}")
                    _state.update {
                        it.copy(
                            isBuffering = false,
                            isPlaying = false,
                            error = "امکان پخش آنلاین این فایل در حال حاضر وجود ندارد."
                        )
                    }
                    true
                }
                prepareAsync()
            }
            mediaPlayer = mp
        } catch (e: Exception) {
            Log.e(TAG, "Failed to prepare MediaPlayer", e)
            _state.update {
                it.copy(
                    isBuffering = false,
                    isPlaying = false,
                    error = "خطا در آماده‌سازی پخش آنلاین"
                )
            }
        }
    }

    fun seekTo(positionMs: Int) {
        try {
            mediaPlayer?.let { mp ->
                if (!_state.value.isBuffering) {
                    mp.seekTo(positionMs)
                    _state.update { it.copy(positionMs = positionMs) }
                }
            }
        } catch (_: Exception) {
        }
    }

    fun stop() {
        releasePlayer()
        _state.update {
            it.copy(
                activeTrack = null,
                isBuffering = false,
                isPlaying = false,
                positionMs = 0,
                durationMs = 0,
                error = null
            )
        }
    }

    private fun startProgressPolling() {
        progressJob?.cancel()
        progressJob = scope.launch(Dispatchers.Main) {
            while (true) {
                val mp = mediaPlayer
                if (mp != null && _state.value.isPlaying) {
                    val pos = runCatching { mp.currentPosition }.getOrDefault(0)
                    _state.update { it.copy(positionMs = pos) }
                } else {
                    break
                }
                delay(250L)
            }
        }
    }

    fun releasePlayer() {
        progressJob?.cancel()
        progressJob = null
        try {
            mediaPlayer?.stop()
        } catch (_: Exception) {
        }
        try {
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        mediaPlayer = null
    }

    companion object {
        private const val TAG = "AudioPlayerManager"
    }
}
