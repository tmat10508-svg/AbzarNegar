package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Persian Horology & Midnight Brass Palette
val TealPrimaryLight = Color(0xFF0F766E)
val TealOnPrimaryLight = Color(0xFFFFFFFF)
val TealContainerLight = Color(0xFFCCFBF1)
val TealOnContainerLight = Color(0xFF042F2E)

val GoldSecondaryLight = Color(0xFFB45309)
val GoldOnSecondaryLight = Color(0xFFFFFFFF)
val GoldContainerLight = Color(0xFFFEF3C7)
val GoldOnContainerLight = Color(0xFF451A03)

val SapphireTertiaryLight = Color(0xFF1D4ED8)
val SapphireContainerLight = Color(0xFFDBEAFE)

val BackgroundLight = Color(0xFFF7F5F0)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFECE8DF)
val OnSurfaceLight = Color(0xFF131B20)
val OnSurfaceVariantLight = Color(0xFF4B5962)
val OutlineLight = Color(0xFFD5CFC3)

// Dark Theme Tokens
val TealPrimaryDark = Color(0xFF2DD4BF)
val TealOnPrimaryDark = Color(0xFF042F2E)
val TealContainerDark = Color(0xFF115E59)
val TealOnContainerDark = Color(0xFFCCFBF1)

val GoldSecondaryDark = Color(0xFFF5B041)
val GoldOnSecondaryDark = Color(0xFF2D1900)
val GoldContainerDark = Color(0xFF5C3404)
val GoldOnContainerDark = Color(0xFFFDE68A)

val SapphireTertiaryDark = Color(0xFF60A5FA)
val SapphireContainerDark = Color(0xFF1E3A8A)

val BackgroundDark = Color(0xFF091216)
val SurfaceDark = Color(0xFF101D23)
val SurfaceVariantDark = Color(0xFF1A2B33)
val OnSurfaceDark = Color(0xFFF1F5F9)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF263B45)

// Accent semantic colors
val WatchBezelDark = Color(0xFF0B2528)
val WatchDialDark = Color(0xFF0D1B20)
val WatchGold = Color(0xFFF5B041)
val WatchSecondHand = Color(0xFFEF4444)
val EmeraldSuccess = Color(0xFF10B981)
