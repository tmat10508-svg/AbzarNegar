package com.example.music

enum class MusicSearchMode(val label: String) {
    ALL("همه (آهنگ، خواننده، متن)"),
    TITLE_ARTIST("نام آهنگ و خواننده"),
    LYRICS("جستجو از روی متن آهنگ")
}

data class MusicTrack(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationSec: Int,
    val artworkUrl: String?,
    val streamUrl: String,
    val downloadUrl: String,
    val qualityLabel: String,
    val sourceName: String,
    val matchedLyricSnippet: String? = null,
    val fullLyrics: String? = null,
    val isFullTrack: Boolean = false
)
