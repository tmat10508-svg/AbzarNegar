package com.example.shopping

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class ShoppingRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    suspend fun searchLowestPriceInIran(query: String): ProductSearchResult =
        withContext(Dispatchers.IO) {
            val trimmed = query.trim()
            if (trimmed.isEmpty()) {
                return@withContext ProductSearchResult(emptyList(), emptyList(), emptyList())
            }

            coroutineScope {
                val torobDeferred = async { searchTorob(trimmed) }
                val digikalaDeferred = async { searchDigikala(trimmed) }

                val torobRes = torobDeferred.await()
                val digikalaRes = digikalaDeferred.await()

                val allOffers = (torobRes.first + digikalaRes.first)
                    .filter { it.isAvailable && it.priceToman > 0L }
                    .sortedBy { it.priceToman }

                val sourcesChecked = listOf("ترب (مقایسه فروشگاه‌های ایران)", "دیجی‌کالا")
                val warnings = listOfNotNull(torobRes.second, digikalaRes.second)

                ProductSearchResult(
                    offers = allOffers,
                    sourcesChecked = sourcesChecked,
                    sourceWarnings = warnings
                )
            }
        }

    private fun searchTorob(query: String): Pair<List<ProductOffer>, String?> {
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://api.torob.com/v4/base-product/search/?q=$encoded&page=0&size=24&sort=price-asc"
            val req = Request.Builder()
                .url(url)
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
                )
                .header("Accept", "application/json, text/plain, */*")
                .header("Accept-Language", "fa-IR,fa;q=0.9,en-US;q=0.8")
                .header("Referer", "https://torob.com/")
                .build()

            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return emptyList<ProductOffer>() to "سرویس ترب پاسخ مستقیم نداد (کد ${resp.code})"
                }
                val body = resp.body?.string() ?: return emptyList<ProductOffer>() to "پاسخ خالی از ترب"
                val root = JSONObject(body)
                val results = root.optJSONArray("results") ?: return emptyList<ProductOffer>() to null
                val list = mutableListOf<ProductOffer>()
                for (i in 0 until results.length()) {
                    val obj = results.getJSONObject(i)
                    val title = obj.optString("name_fa", obj.optString("name_en", "")).trim()
                    val priceToman = obj.optLong("price_toman", 0L)
                    val oldPrice = obj.optLong("old_price_toman", 0L).takeIf { it > priceToman }
                    val available = obj.optBoolean("available", priceToman > 0L)
                    val shopName = obj.optString("shop_name", "فروشگاه‌های ترب")
                        .takeIf { it.isNotBlank() && it != "null" }
                        ?: "فروشگاه‌های عضو ترب"
                    val imgUrl = obj.optString("img_url", "")
                        .takeIf { it.startsWith("http") }
                    val webPath = obj.optString("web_page_url", "")
                    val fullUrl = when {
                        webPath.startsWith("http") -> webPath
                        webPath.startsWith("/") -> "https://torob.com$webPath"
                        else -> "https://torob.com/search/?query=$encoded"
                    }
                    val prk = obj.optString("prk", obj.optString("random_key", "t_$i"))
                    val discount = if (oldPrice != null && oldPrice > 0) {
                        (((oldPrice - priceToman) * 100) / oldPrice).toInt().coerceIn(0, 99)
                    } else 0

                    if (title.isNotEmpty() && priceToman > 0L && available) {
                        list.add(
                            ProductOffer(
                                id = "torob_$prk",
                                title = title,
                                priceToman = priceToman,
                                oldPriceToman = oldPrice,
                                discountPercent = discount,
                                shopName = shopName,
                                marketplace = "ترب",
                                imageUrl = imgUrl,
                                productUrl = fullUrl,
                                isAvailable = true
                            )
                        )
                    }
                }
                list to null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Torob search failed: ${e.message}")
            emptyList<ProductOffer>() to "خطا در اتصال به ترب"
        }
    }

    private fun searchDigikala(query: String): Pair<List<ProductOffer>, String?> {
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            // sort=20 sorts by lowest price on Digikala
            val url = "https://api.digikala.com/v1/search/?q=$encoded&sort=20&page=1"
            val req = Request.Builder()
                .url(url)
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
                )
                .header("Accept", "application/json")
                .build()

            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return emptyList<ProductOffer>() to "دیجی‌کالا پاسخ مستقیم نداد (کد ${resp.code})"
                }
                val body = resp.body?.string() ?: return emptyList<ProductOffer>() to "پاسخ خالی از دیجی‌کالا"
                val root = JSONObject(body)
                val data = root.optJSONObject("data") ?: return emptyList<ProductOffer>() to null
                val products = data.optJSONArray("products") ?: return emptyList<ProductOffer>() to null
                val list = mutableListOf<ProductOffer>()
                for (i in 0 until products.length()) {
                    val obj = products.getJSONObject(i)
                    val id = obj.optLong("id", i.toLong())
                    val title = obj.optString("title_fa", "").trim()
                    val status = obj.optString("status", "marketable")
                    if (status != "marketable") continue

                    val variant = obj.optJSONObject("default_variant") ?: continue
                    val priceObj = variant.optJSONObject("price") ?: continue
                    val sellingRial = priceObj.optLong("selling_price", 0L)
                    if (sellingRial <= 0L) continue
                    val priceToman = sellingRial / 10L
                    val rrpRial = priceObj.optLong("rrp_price", 0L)
                    val oldPriceToman = (rrpRial / 10L).takeIf { it > priceToman }
                    val discount = priceObj.optInt("discount_percent", 0)

                    val sellerObj = variant.optJSONObject("seller")
                    val sellerTitle = sellerObj?.optString("title", "دیجی‌کالا")?.ifBlank { "دیجی‌کالا" }
                        ?: "دیجی‌کالا"

                    val imagesObj = obj.optJSONObject("images")
                    val mainImg = imagesObj?.optJSONObject("main")
                    val urlArr = mainImg?.optJSONArray("url")
                    val imgUrl = if (urlArr != null && urlArr.length() > 0) urlArr.optString(0) else null

                    val urlObj = obj.optJSONObject("url")
                    val uri = urlObj?.optString("uri", "") ?: ""
                    val fullUrl = when {
                        uri.startsWith("http") -> uri
                        uri.startsWith("/") -> "https://www.digikala.com$uri"
                        else -> "https://www.digikala.com/product/dkp-$id/"
                    }

                    if (title.isNotEmpty() && priceToman > 0L) {
                        list.add(
                            ProductOffer(
                                id = "dk_$id",
                                title = title,
                                priceToman = priceToman,
                                oldPriceToman = oldPriceToman,
                                discountPercent = discount,
                                shopName = sellerTitle,
                                marketplace = "دیجی‌کالا",
                                imageUrl = imgUrl?.takeIf { it.startsWith("http") },
                                productUrl = fullUrl,
                                isAvailable = true
                            )
                        )
                    }
                }
                list to null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Digikala search failed: ${e.message}")
            emptyList<ProductOffer>() to "خطا در اتصال به دیجی‌کالا"
        }
    }

    companion object {
        private const val TAG = "ShoppingRepository"
    }
}
