package com.example.profile

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.profileDataStore: DataStore<Preferences> by preferencesDataStore(name = "user_profile_prefs")

data class UserProfile(
    val fullName: String = "کارت اطلاعات من",
    val jobTitle: String = "شماره تماس و مشخصات شخصی",
    val phoneNumber: String = DEFAULT_PHONE,
    val secondaryPhone: String = "",
    val city: String = "ایران",
    val email: String = "",
    val socialId: String = "",
    val bio: String = "برای برقراری تماس یا ارسال پیام می‌توانید از دکمه‌های زیر استفاده کنید."
) {
    companion object {
        const val DEFAULT_PHONE = "09161112725"
    }
}

class ProfileRepository(private val context: Context) {

    private object Keys {
        val FULL_NAME = stringPreferencesKey("full_name")
        val JOB_TITLE = stringPreferencesKey("job_title")
        val PHONE_NUMBER = stringPreferencesKey("phone_number")
        val SECONDARY_PHONE = stringPreferencesKey("secondary_phone")
        val CITY = stringPreferencesKey("city")
        val EMAIL = stringPreferencesKey("email")
        val SOCIAL_ID = stringPreferencesKey("social_id")
        val BIO = stringPreferencesKey("bio")
    }

    val profileFlow: Flow<UserProfile> = context.profileDataStore.data.map { prefs ->
        UserProfile(
            fullName = prefs[Keys.FULL_NAME] ?: "کارت اطلاعات من",
            jobTitle = prefs[Keys.JOB_TITLE] ?: "شماره تماس و مشخصات شخصی",
            phoneNumber = prefs[Keys.PHONE_NUMBER]?.ifBlank { UserProfile.DEFAULT_PHONE }
                ?: UserProfile.DEFAULT_PHONE,
            secondaryPhone = prefs[Keys.SECONDARY_PHONE] ?: "",
            city = prefs[Keys.CITY] ?: "ایران",
            email = prefs[Keys.EMAIL] ?: "",
            socialId = prefs[Keys.SOCIAL_ID] ?: "",
            bio = prefs[Keys.BIO] ?: "برای برقراری تماس یا ارسال پیام می‌توانید از دکمه‌های زیر استفاده کنید."
        )
    }

    suspend fun saveProfile(profile: UserProfile) {
        context.profileDataStore.edit { prefs ->
            prefs[Keys.FULL_NAME] = profile.fullName.trim().ifEmpty { "کارت اطلاعات من" }
            prefs[Keys.JOB_TITLE] = profile.jobTitle.trim()
            prefs[Keys.PHONE_NUMBER] = profile.phoneNumber.trim().ifEmpty { UserProfile.DEFAULT_PHONE }
            prefs[Keys.SECONDARY_PHONE] = profile.secondaryPhone.trim()
            prefs[Keys.CITY] = profile.city.trim()
            prefs[Keys.EMAIL] = profile.email.trim()
            prefs[Keys.SOCIAL_ID] = profile.socialId.trim()
            prefs[Keys.BIO] = profile.bio.trim()
        }
    }
}
