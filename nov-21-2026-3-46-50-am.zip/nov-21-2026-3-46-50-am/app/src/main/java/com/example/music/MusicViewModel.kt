package com.example.music

import android.app.Application
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface MusicUiState {
    data object Idle : MusicUiState
    data object Loading : MusicUiState
    data class Success(val tracks: List<MusicTrack>) : MusicUiState
    data class Error(val message: String) : MusicUiState
}

class MusicViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MusicRepository()
    private val playerManager = AudioPlayerManager(viewModelScope)

    val playerState: StateFlow<AudioPlayerState> = playerManager.state

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _searchMode = MutableStateFlow(MusicSearchMode.ALL)
    val searchMode: StateFlow<MusicSearchMode> = _searchMode.asStateFlow()

    private val _uiState = MutableStateFlow<MusicUiState>(MusicUiState.Idle)
    val uiState: StateFlow<MusicUiState> = _uiState.asStateFlow()

    private val _downloadedTrackIds = MutableStateFlow<Set<String>>(emptySet())
    val downloadedTrackIds: StateFlow<Set<String>> = _downloadedTrackIds.asStateFlow()

    fun updateQuery(newQuery: String) {
        _query.value = newQuery
    }

    fun updateSearchMode(mode: MusicSearchMode) {
        _searchMode.value = mode
        if (_query.value.isNotBlank()) {
            search(_query.value)
        }
    }

    fun search(customQuery: String = _query.value) {
        val trimmed = customQuery.trim()
        if (trimmed.isEmpty()) return
        _query.value = trimmed

        viewModelScope.launch {
            _uiState.value = MusicUiState.Loading
            try {
                val results = repository.searchMusic(trimmed, _searchMode.value)
                if (results.isEmpty()) {
                    _uiState.value = MusicUiState.Error(
                        "آهنگی با این مشخصات پیدا نشد. نام آهنگ، نام خواننده یا عبارت کوتاه‌تری از متن را امتحان کنید."
                    )
                } else {
                    _uiState.value = MusicUiState.Success(results)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.value = MusicUiState.Error(
                    "خطا در برقراری ارتباط با سرور موزیک: ${e.localizedMessage ?: "اتصال اینترنت را بررسی کنید"}"
                )
            }
        }
    }

    fun togglePlay(track: MusicTrack) {
        playerManager.togglePlay(track)
    }

    fun seekTo(positionMs: Int) {
        playerManager.seekTo(positionMs)
    }

    fun stopPlayer() {
        playerManager.stop()
    }

    fun downloadTrackMp3(track: MusicTrack, onResult: (String) -> Unit) {
        val context = getApplication<Application>().applicationContext
        try {
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val safeTitle = "${track.artist} - ${track.title}"
                .replace(Regex("[^\\p{L}\\p{N}\\s_-]"), "")
                .trim()
                .ifEmpty { "music_track" }
                .take(64)
            val ext = if (track.downloadUrl.contains(".m4a", ignoreCase = true)) "m4a" else "mp3"
            val fileName = "$safeTitle.$ext"

            val request = DownloadManager.Request(Uri.parse(track.downloadUrl)).apply {
                setTitle("${track.title} - ${track.artist}")
                setDescription("در حال دانلود فایل صوتی با کیفیت بالا...")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setAllowedOverMetered(true)
                setAllowedOverRoaming(true)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "AbzarNegar/$fileName")
            }
            dm.enqueue(request)
            _downloadedTrackIds.update { it + track.id }
            onResult("دانلود «${track.title}» در پوشه Downloads/AbzarNegar آغاز شد")
        } catch (e: Exception) {
            onResult("خطا در شروع دانلود: ${e.localizedMessage ?: "نامشخص"}")
        }
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.releasePlayer()
    }
}
