package com.example.calculator

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import kotlin.math.ln
import kotlin.math.pow

/**
 * High-precision arbitrary-length calculator engine supporting 80+ significant digits,
 * full expression parsing with operator precedence, and thousand-separator formatting.
 */
object BigCalculatorEngine {

    // 80 digits precision ensures accuracy well beyond 50 digits
    val MATH_CONTEXT: MathContext = MathContext(80, RoundingMode.HALF_UP)

    // 70-digit precision constants
    val PI_BIG = BigDecimal("3.141592653589793238462643383279502884197169399375105820974944592307816406")
    val E_BIG = BigDecimal("2.718281828459045235360287471352662497757247093699959574966967627724076630")

    sealed interface CalcResult {
        data class Success(val value: BigDecimal, val formatted: String, val digitCount: Int) : CalcResult
        data class Error(val message: String) : CalcResult
    }

    fun evaluate(rawExpression: String): CalcResult {
        val cleaned = rawExpression
            .replace(",", "")
            .replace("٬", "")
            .replace(" ", "")
            .replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")
            .trim()

        if (cleaned.isEmpty()) {
            return CalcResult.Success(BigDecimal.ZERO, "0", 1)
        }

        return try {
            val parser = Parser(cleaned)
            val result = parser.parseExpression()
            if (!parser.isAtEnd()) {
                return CalcResult.Error("عبارت نامعتبر است")
            }
            val normalized = normalizeBigDecimal(result)
            val formatted = formatBigDecimalWithSeparators(normalized)
            val digitsOnly = normalized.toPlainString().count { it.isDigit() }
            CalcResult.Success(normalized, formatted, digitsOnly)
        } catch (e: ArithmeticException) {
            CalcResult.Error(e.message ?: "خطای محاسباتی (تقسیم بر صفر یا مقدار نامعتبر)")
        } catch (e: IllegalArgumentException) {
            CalcResult.Error(e.message ?: "ساختار عبارت ریاضی صحیح نیست")
        } catch (_: Exception) {
            CalcResult.Error("خطا در محاسبه عبارت")
        }
    }

    fun normalizeBigDecimal(value: BigDecimal): BigDecimal {
        if (value.compareTo(BigDecimal.ZERO) == 0) return BigDecimal.ZERO
        // Round to 68 digits to eliminate trailing precision noise from division/sqrt/trig,
        // while still guaranteeing >50 exact digits!
        val rounded = value.round(MathContext(68, RoundingMode.HALF_UP))
        val stripped = rounded.stripTrailingZeros()
        return if (stripped.scale() < 0) stripped.setScale(0) else stripped
    }

    fun formatBigDecimalWithSeparators(value: BigDecimal): String {
        val plain = value.toPlainString()
        return formatNumericStringWithCommas(plain)
    }

    fun formatNumericStringWithCommas(numeric: String): String {
        if (numeric.isEmpty()) return ""
        val isNegative = numeric.startsWith("-")
        val body = if (isNegative) numeric.substring(1) else numeric
        val dotIndex = body.indexOf('.')
        val intPart = if (dotIndex >= 0) body.substring(0, dotIndex) else body
        val fracPart = if (dotIndex >= 0) body.substring(dotIndex) else ""

        val intWithCommas = if (intPart.length <= 3) {
            intPart
        } else {
            val sb = StringBuilder()
            var count = 0
            for (i in intPart.length - 1 downTo 0) {
                sb.append(intPart[i])
                count++
                if (count % 3 == 0 && i != 0) {
                    sb.append(',')
                }
            }
            sb.reverse().toString()
        }

        return (if (isNegative) "-" else "") + intWithCommas + fracPart
    }

    /**
     * Formats an entire mathematical expression so every number token has comma thousand separators.
     */
    fun formatExpressionWithSeparators(rawExpression: String): String {
        val noCommas = rawExpression.replace(",", "")
        val result = StringBuilder()
        val token = StringBuilder()

        fun flushToken() {
            if (token.isNotEmpty()) {
                result.append(formatNumericStringWithCommas(token.toString()))
                token.clear()
            }
        }

        for (ch in noCommas) {
            if (ch.isDigit() || ch == '.') {
                token.append(ch)
            } else {
                flushToken()
                result.append(ch)
            }
        }
        flushToken()
        return result.toString()
    }

    fun countDigitsInExpression(rawExpression: String): Int {
        var maxDigits = 0
        var currentDigits = 0
        for (ch in rawExpression) {
            if (ch.isDigit()) {
                currentDigits++
                if (currentDigits > maxDigits) maxDigits = currentDigits
            } else if (ch != ',' && ch != '.') {
                currentDigits = 0
            }
        }
        return maxDigits
    }

    fun bigSqrt(x: BigDecimal): BigDecimal {
        if (x < BigDecimal.ZERO) {
            throw ArithmeticException("جذر عدد منفی تعریف نشده است")
        }
        if (x.compareTo(BigDecimal.ZERO) == 0) return BigDecimal.ZERO

        // Initial estimate using double or bit scaling for arbitrarily huge/tiny numbers
        var estimate = try {
            val d = x.toDouble()
            if (d.isFinite() && d > 0.0) {
                BigDecimal(kotlin.math.sqrt(d), MATH_CONTEXT)
            } else {
                scaleInitialSqrtEstimate(x)
            }
        } catch (_: Exception) {
            scaleInitialSqrtEstimate(x)
        }

        if (estimate.compareTo(BigDecimal.ZERO) == 0) {
            estimate = scaleInitialSqrtEstimate(x)
        }

        val two = BigDecimal(2)
        val epsilon = BigDecimal.ONE.movePointLeft(72)
        for (i in 0 until 120) {
            val next = estimate.add(x.divide(estimate, MATH_CONTEXT)).divide(two, MATH_CONTEXT)
            if (next.subtract(estimate).abs() <= epsilon) {
                return next
            }
            estimate = next
        }
        return estimate
    }

    private fun scaleInitialSqrtEstimate(x: BigDecimal): BigDecimal {
        val unscaledDigits = x.unscaledValue().toString().length
        val exp10 = (unscaledDigits - x.scale()) / 2
        return BigDecimal.ONE.scaleByPowerOfTen(exp10)
    }

    fun bigFactorial(n: BigDecimal): BigDecimal {
        if (n < BigDecimal.ZERO || n.stripTrailingZeros().scale() > 0) {
            throw ArithmeticException("فاکتوریل فقط برای اعداد صحیح نامنفی است")
        }
        val intVal = n.toInt()
        if (intVal > 500) {
            throw ArithmeticException("حداکثر مقدار فاکتوریل ۵۰۰ است")
        }
        var acc = BigDecimal.ONE
        for (i in 2..intVal) {
            acc = acc.multiply(BigDecimal(i), MATH_CONTEXT)
        }
        return acc
    }

    fun bigPower(base: BigDecimal, exp: BigDecimal): BigDecimal {
        val strippedExp = exp.stripTrailingZeros()
        if (strippedExp.compareTo(BigDecimal.ZERO) == 0) return BigDecimal.ONE
        if (strippedExp.scale() <= 0) {
            val intExp = try {
                strippedExp.intValueExact()
            } catch (_: ArithmeticException) {
                throw ArithmeticException("توان عدد صحیح بیش از حد بزرگ است")
            }
            if (kotlin.math.abs(intExp) > 10000) {
                throw ArithmeticException("توان بیش از حد بزرگ است")
            }
            return if (intExp >= 0) {
                base.pow(intExp, MATH_CONTEXT)
            } else {
                if (base.compareTo(BigDecimal.ZERO) == 0) {
                    throw ArithmeticException("تقسیم بر صفر در توان منفی")
                }
                BigDecimal.ONE.divide(base.pow(-intExp, MATH_CONTEXT), MATH_CONTEXT)
            }
        }
        // Fractional power fallback via high-precision double where finite
        val b = base.toDouble()
        val e = exp.toDouble()
        if (!b.isFinite() || !e.isFinite() || (b < 0 && e % 1.0 != 0.0)) {
            throw ArithmeticException("توان اعشاری برای این مقدار مجاز نیست")
        }
        val res = b.pow(e)
        if (!res.isFinite()) throw ArithmeticException("سرریز در محاسبه توان")
        return BigDecimal(res, MATH_CONTEXT)
    }

    private class Parser(private val input: String) {
        private var pos = 0

        fun isAtEnd(): Boolean = pos >= input.length

        private fun peek(): Char = if (pos < input.length) input[pos] else '\u0000'

        private fun consume(): Char = input[pos++]

        fun parseExpression(): BigDecimal {
            var left = parseTerm()
            while (pos < input.length) {
                when (peek()) {
                    '+' -> {
                        consume()
                        left = left.add(parseTerm(), MATH_CONTEXT)
                    }
                    '-' -> {
                        consume()
                        left = left.subtract(parseTerm(), MATH_CONTEXT)
                    }
                    else -> break
                }
            }
            return left
        }

        private fun parseTerm(): BigDecimal {
            var left = parsePower()
            while (pos < input.length) {
                when (peek()) {
                    '*' -> {
                        consume()
                        left = left.multiply(parsePower(), MATH_CONTEXT)
                    }
                    '/' -> {
                        consume()
                        val right = parsePower()
                        if (right.compareTo(BigDecimal.ZERO) == 0) {
                            throw ArithmeticException("تقسیم بر صفر مجاز نیست")
                        }
                        left = left.divide(right, MATH_CONTEXT)
                    }
                    '(' , '√', 'π', 'e' -> {
                        // Implicit multiplication like 2(3+4) or 2π
                        left = left.multiply(parsePower(), MATH_CONTEXT)
                    }
                    else -> break
                }
            }
            return left
        }

        private fun parsePower(): BigDecimal {
            var base = parseUnary()
            if (pos < input.length && peek() == '^') {
                consume()
                val exponent = parsePower() // right-associative
                base = bigPower(base, exponent)
            }
            return base
        }

        private fun parseUnary(): BigDecimal {
            return when (peek()) {
                '+' -> {
                    consume()
                    parseUnary()
                }
                '-' -> {
                    consume()
                    parseUnary().negate()
                }
                else -> parsePostfix()
            }
        }

        private fun parsePostfix(): BigDecimal {
            var value = parsePrimary()
            while (pos < input.length) {
                when (peek()) {
                    '%' -> {
                        consume()
                        value = value.divide(BigDecimal(100), MATH_CONTEXT)
                    }
                    '!' -> {
                        consume()
                        value = bigFactorial(value)
                    }
                    else -> break
                }
            }
            return value
        }

        private fun parsePrimary(): BigDecimal {
            if (pos >= input.length) {
                throw IllegalArgumentException("عبارت ناقص است")
            }
            return when (peek()) {
                '(' -> {
                    consume()
                    val inner = parseExpression()
                    if (peek() != ')') throw IllegalArgumentException("پرانتز بسته نشده است")
                    consume()
                    inner
                }
                '√' -> {
                    consume()
                    val operand = if (peek() == '(') {
                        parsePrimary()
                    } else {
                        parseUnary()
                    }
                    bigSqrt(operand)
                }
                'π' -> {
                    consume()
                    PI_BIG
                }
                'e' -> {
                    consume()
                    E_BIG
                }
                else -> parseNumber()
            }
        }

        private fun parseNumber(): BigDecimal {
            val start = pos
            var dotSeen = false
            while (pos < input.length) {
                val c = peek()
                if (c.isDigit()) {
                    pos++
                } else if (c == '.' && !dotSeen) {
                    dotSeen = true
                    pos++
                } else {
                    break
                }
            }
            if (start == pos) {
                throw IllegalArgumentException("عدد نامعتبر در موقعیت $pos")
            }
            val numStr = input.substring(start, pos)
            if (numStr == ".") return BigDecimal.ZERO
            return BigDecimal(numStr)
        }
    }
}
