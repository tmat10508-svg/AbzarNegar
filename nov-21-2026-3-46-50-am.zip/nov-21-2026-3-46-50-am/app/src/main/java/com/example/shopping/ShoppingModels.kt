package com.example.shopping

data class ProductOffer(
    val id: String,
    val title: String,
    val priceToman: Long,
    val oldPriceToman: Long? = null,
    val discountPercent: Int = 0,
    val shopName: String,
    val marketplace: String,
    val imageUrl: String? = null,
    val productUrl: String,
    val isAvailable: Boolean = true
)

data class ProductSearchResult(
    val offers: List<ProductOffer>,
    val sourcesChecked: List<String>,
    val sourceWarnings: List<String>
)
