package com.example.calculator

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Functions
import androidx.compose.material.icons.rounded.History
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.WatchGold
import com.example.util.PersianUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
    viewModel: CalculatorViewModel,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current
    var showHistorySheet by remember { mutableStateOf(false) }

    val copiedMsg = stringResource(R.string.calc_copied)

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Precision Display Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false)
                    .heightIn(min = 148.dp),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 4.dp,
                shadowElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    MaterialTheme.colorScheme.surface,
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                                )
                            )
                        )
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Header Badges & Tools
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                val badgeDigits = maxOf(state.currentMaxDigits, state.resultDigitsCount)
                                Text(
                                    text = if (badgeDigits > 0) {
                                        "دقت +۸۰ رقم • ${PersianUtils.toPersianDigits(badgeDigits.toString())} رقم"
                                    } else {
                                        "دقت بیش از ۵۰ رقم"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { viewModel.toggleScientificRow() },
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Functions,
                                    contentDescription = "توابع علمی",
                                    tint = if (state.showScientificRow) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = { showHistorySheet = true },
                                modifier = Modifier
                                    .size(40.dp)
                                    .testTag("calc_history_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.History,
                                    contentDescription = stringResource(R.string.calc_history),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = {
                                    val textToCopy = state.finalResult
                                        ?: state.previewResult.ifEmpty { state.formattedExpression }
                                    clipboard.setText(AnnotatedString(textToCopy))
                                    onShowMessage(copiedMsg)
                                },
                                modifier = Modifier
                                    .size(40.dp)
                                    .testTag("calc_copy_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ContentCopy,
                                    contentDescription = stringResource(R.string.calc_copy),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Expression Scrollable LTR Display
                    val exprScroll = rememberScrollState()
                    LaunchedEffect(state.formattedExpression) {
                        exprScroll.animateScrollTo(exprScroll.maxValue)
                    }

                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.End
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(exprScroll),
                                contentAlignment = Alignment.CenterEnd
                            ) {
                                Text(
                                    text = state.formattedExpression,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = if (state.finalResult != null) FontWeight.Normal else FontWeight.SemiBold,
                                    fontSize = when {
                                        state.formattedExpression.length > 36 -> 18.sp
                                        state.formattedExpression.length > 20 -> 22.sp
                                        else -> 28.sp
                                    },
                                    color = if (state.finalResult != null) {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    },
                                    maxLines = 1,
                                    modifier = Modifier.testTag("calc_expression_text")
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            val resultScroll = rememberScrollState()
                            val mainResultText = state.errorMessage
                                ?: state.finalResult
                                ?: state.previewResult

                            if (mainResultText.isNotEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(resultScroll),
                                    contentAlignment = Alignment.CenterEnd
                                ) {
                                    Text(
                                        text = if (state.errorMessage != null) {
                                            mainResultText
                                        } else if (state.finalResult != null) {
                                            "= $mainResultText"
                                        } else {
                                            "= $mainResultText"
                                        },
                                        fontFamily = if (state.errorMessage != null) {
                                            MaterialTheme.typography.bodyMedium.fontFamily
                                        } else {
                                            JetBrainsMonoFontFamily
                                        },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = when {
                                            state.errorMessage != null -> 14.sp
                                            mainResultText.length > 35 -> 20.sp
                                            mainResultText.length > 18 -> 24.sp
                                            else -> 32.sp
                                        },
                                        color = when {
                                            state.errorMessage != null -> MaterialTheme.colorScheme.error
                                            state.finalResult != null -> MaterialTheme.colorScheme.primary
                                            else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f)
                                        },
                                        maxLines = 1,
                                        modifier = Modifier.testTag("calc_result_text")
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Scientific Functions Row
            AnimatedVisibility(visible = state.showScientificRow) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val sciButtons = listOf(
                            "(" to { viewModel.appendToken("(") },
                            ")" to { viewModel.appendToken(")") },
                            "√" to { viewModel.appendToken("√(") },
                            "x^y" to { viewModel.appendToken("^") },
                            "x²" to { viewModel.square() },
                            "1/x" to { viewModel.reciprocal() },
                            "n!" to { viewModel.appendToken("!") },
                            "π" to { viewModel.appendToken("π") }
                        )
                        sciButtons.forEach { (label, action) ->
                            FilledTonalButton(
                                onClick = action,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(
                                    text = label,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            // Main 5x4 Keypad (Forced LTR so standard keypad layout stays natural)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1.35f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KeypadRow(modifier = Modifier.weight(1f)) {
                        CalcKey("AC", KeyStyle.Danger, Modifier.weight(1f).testTag("calc_key_ac")) { viewModel.clearAll() }
                        CalcKey("±", KeyStyle.Operator, Modifier.weight(1f)) { viewModel.toggleSign() }
                        CalcKey("%", KeyStyle.Operator, Modifier.weight(1f)) { viewModel.appendToken("%") }
                        CalcKey("÷", KeyStyle.Operator, Modifier.weight(1f)) { viewModel.appendToken("÷") }
                    }
                    KeypadRow(modifier = Modifier.weight(1f)) {
                        CalcKey("7", KeyStyle.Digit, Modifier.weight(1f).testTag("calc_key_7")) { viewModel.appendToken("7") }
                        CalcKey("8", KeyStyle.Digit, Modifier.weight(1f).testTag("calc_key_8")) { viewModel.appendToken("8") }
                        CalcKey("9", KeyStyle.Digit, Modifier.weight(1f).testTag("calc_key_9")) { viewModel.appendToken("9") }
                        CalcKey("×", KeyStyle.Operator, Modifier.weight(1f).testTag("calc_key_mul")) { viewModel.appendToken("×") }
                    }
                    KeypadRow(modifier = Modifier.weight(1f)) {
                        CalcKey("4", KeyStyle.Digit, Modifier.weight(1f)) { viewModel.appendToken("4") }
                        CalcKey("5", KeyStyle.Digit, Modifier.weight(1f)) { viewModel.appendToken("5") }
                        CalcKey("6", KeyStyle.Digit, Modifier.weight(1f)) { viewModel.appendToken("6") }
                        CalcKey("-", KeyStyle.Operator, Modifier.weight(1f)) { viewModel.appendToken("-") }
                    }
                    KeypadRow(modifier = Modifier.weight(1f)) {
                        CalcKey("1", KeyStyle.Digit, Modifier.weight(1f).testTag("calc_key_1")) { viewModel.appendToken("1") }
                        CalcKey("2", KeyStyle.Digit, Modifier.weight(1f).testTag("calc_key_2")) { viewModel.appendToken("2") }
                        CalcKey("3", KeyStyle.Digit, Modifier.weight(1f).testTag("calc_key_3")) { viewModel.appendToken("3") }
                        CalcKey("+", KeyStyle.Operator, Modifier.weight(1f).testTag("calc_key_add")) { viewModel.appendToken("+") }
                    }
                    KeypadRow(modifier = Modifier.weight(1f)) {
                        CalcKey("00", KeyStyle.Digit, Modifier.weight(1f)) { viewModel.appendToken("00") }
                        CalcKey("0", KeyStyle.Digit, Modifier.weight(1f)) { viewModel.appendToken("0") }
                        CalcKey(".", KeyStyle.Digit, Modifier.weight(1f)) { viewModel.appendToken(".") }
                        Row(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilledTonalButton(
                                onClick = { viewModel.backspace() },
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxSize(),
                                shape = RoundedCornerShape(16.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.Backspace,
                                    contentDescription = "پاک کردن آخرین رقم",
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Button(
                                onClick = { viewModel.evaluateFinal() },
                                modifier = Modifier
                                    .weight(1.2f)
                                    .fillMaxSize()
                                    .testTag("calc_key_equals"),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(
                                    text = "=",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showHistorySheet) {
        ModalBottomSheet(onDismissRequest = { showHistorySheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.calc_history),
                        style = MaterialTheme.typography.titleLarge
                    )
                    if (state.history.isNotEmpty()) {
                        TextButton(onClick = { viewModel.clearHistory() }) {
                            Icon(
                                imageVector = Icons.Rounded.DeleteOutline,
                                contentDescription = "پاک کردن تاریخچه",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text("پاک کردن")
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                if (state.history.isEmpty()) {
                    Text(
                        text = "هنوز محاسبه‌ای ثبت نشده است.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 24.dp)
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 360.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(state.history, key = { it.id }) { item ->
                            Surface(
                                onClick = {
                                    viewModel.loadHistoryItem(item)
                                    showHistorySheet = false
                                },
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp)
                                ) {
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                        Text(
                                            text = item.expression,
                                            fontFamily = JetBrainsMonoFontFamily,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.fillMaxWidth(),
                                            textAlign = TextAlign.End
                                        )
                                        Text(
                                            text = "= ${item.result}",
                                            fontFamily = JetBrainsMonoFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.fillMaxWidth(),
                                            textAlign = TextAlign.End
                                        )
                                    }
                                    Text(
                                        text = "${PersianUtils.toPersianDigits(item.digitCount.toString())} رقم",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = WatchGold
                                    )
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun KeypadRow(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        content()
    }
}

private enum class KeyStyle { Digit, Operator, Danger }

@Composable
private fun CalcKey(
    label: String,
    style: KeyStyle,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val containerColor = when (style) {
        KeyStyle.Digit -> MaterialTheme.colorScheme.surface
        KeyStyle.Operator -> MaterialTheme.colorScheme.secondaryContainer
        KeyStyle.Danger -> MaterialTheme.colorScheme.errorContainer
    }
    val contentColor = when (style) {
        KeyStyle.Digit -> MaterialTheme.colorScheme.onSurface
        KeyStyle.Operator -> MaterialTheme.colorScheme.onSecondaryContainer
        KeyStyle.Danger -> MaterialTheme.colorScheme.onErrorContainer
    }

    Button(
        onClick = onClick,
        modifier = modifier.fillMaxSize(),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 1.dp),
        contentPadding = PaddingValues(0.dp)
    ) {
        Text(
            text = label,
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
