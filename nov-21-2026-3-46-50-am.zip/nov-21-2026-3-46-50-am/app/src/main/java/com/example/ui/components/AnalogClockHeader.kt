package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.OpenInFull
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.WatchBezelDark
import com.example.ui.theme.WatchDialDark
import com.example.ui.theme.WatchGold
import com.example.ui.theme.WatchSecondHand
import com.example.util.PersianUtils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.delay

@Composable
fun AnalogClockHeader(
    modifier: Modifier = Modifier
) {
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showExpandedClock by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            nowMillis = System.currentTimeMillis()
            delay(50L)
        }
    }

    val calendar = remember(nowMillis / 1000L) {
        Calendar.getInstance().apply { timeInMillis = nowMillis }
    }
    val seconds = calendar.get(Calendar.SECOND) + (nowMillis % 1000L) / 1000f
    val minutes = calendar.get(Calendar.MINUTE) + seconds / 60f
    val hours = (calendar.get(Calendar.HOUR) % 12) + minutes / 60f

    val digitalTime = remember(nowMillis / 1000L) {
        SimpleDateFormat("HH:mm:ss", Locale.US).format(calendar.time)
    }
    val jalaliDate = remember(calendar.get(Calendar.DAY_OF_YEAR), calendar.get(Calendar.YEAR)) {
        PersianUtils.formatJalaliDate(calendar)
    }
    val gregorianDate = remember(calendar.get(Calendar.DAY_OF_YEAR), calendar.get(Calendar.YEAR)) {
        SimpleDateFormat("yyyy/MM/dd", Locale.US).format(calendar.time)
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = WatchBezelDark,
        shadowElevation = 6.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFF081B1E),
                            Color(0xFF0E2F34),
                            Color(0xFF091F23)
                        )
                    )
                )
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { showExpandedClock = true }
                    .padding(horizontal = 6.dp, vertical = 4.dp)
                    .testTag("analog_clock_header"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    AnalogClockFace(
                        hours = hours,
                        minutes = minutes,
                        seconds = seconds,
                        size = 74.dp,
                        showSubtleGlow = true
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleMedium,
                                color = WatchGold,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                color = Color(0xFF15454B),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = jalaliDate,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFFCCFBF1),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(
                                text = digitalTime,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp,
                                color = Color.White,
                                letterSpacing = 1.5.sp
                            )
                        }
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(
                                text = gregorianDate,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF133A40)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.OpenInFull,
                        contentDescription = stringResource(R.string.clock_expand_desc),
                        tint = WatchGold,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }

    if (showExpandedClock) {
        AlertDialog(
            onDismissRequest = { showExpandedClock = false },
            containerColor = WatchDialDark,
            titleContentColor = WatchGold,
            title = {
                Text(
                    text = jalaliDate,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    AnalogClockFace(
                        hours = hours,
                        minutes = minutes,
                        seconds = seconds,
                        size = 230.dp,
                        showSubtleGlow = true
                    )
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text(
                            text = digitalTime,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 30.sp,
                            color = Color.White,
                            letterSpacing = 2.sp
                        )
                    }
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text(
                            text = gregorianDate,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 13.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showExpandedClock = false }) {
                    Text("بستن", color = WatchGold)
                }
            }
        )
    }
}

@Composable
fun AnalogClockFace(
    hours: Float,
    minutes: Float,
    seconds: Float,
    size: Dp,
    showSubtleGlow: Boolean = true,
    modifier: Modifier = Modifier
) {
    val desc = stringResource(R.string.clock_title)
    Canvas(
        modifier = modifier
            .size(size)
            .shadow(if (showSubtleGlow) 8.dp else 0.dp, CircleShape, ambientColor = WatchGold)
            .clip(CircleShape)
            .semantics { contentDescription = desc }
    ) {
        val radius = this.size.minDimension / 2f
        val center = Offset(this.size.width / 2f, this.size.height / 2f)

        // Dial background
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF14353B), WatchDialDark, Color(0xFF061114)),
                center = center,
                radius = radius
            ),
            radius = radius,
            center = center
        )

        // Outer metallic gold bezel
        drawCircle(
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFFFDE68A), WatchGold, Color(0xFFB45309), WatchGold)
            ),
            radius = radius - 2.dp.toPx(),
            center = center,
            style = Stroke(width = 2.8.dp.toPx())
        )

        // Inner delicate chapter ring
        drawCircle(
            color = Color(0xFF2DD4BF).copy(alpha = 0.28f),
            radius = radius * 0.82f,
            center = center,
            style = Stroke(width = 0.8.dp.toPx())
        )

        // 60 tick marks
        for (i in 0 until 60) {
            val angleRad = (i * 6f - 90f) * (PI / 180f)
            val isHourMark = i % 5 == 0
            val isQuarterMark = i % 15 == 0
            val innerFactor = when {
                isQuarterMark -> 0.72f
                isHourMark -> 0.77f
                else -> 0.85f
            }
            val start = Offset(
                x = center.x + (radius * innerFactor * cos(angleRad)).toFloat(),
                y = center.y + (radius * innerFactor * sin(angleRad)).toFloat()
            )
            val end = Offset(
                x = center.x + (radius * 0.90f * cos(angleRad)).toFloat(),
                y = center.y + (radius * 0.90f * sin(angleRad)).toFloat()
            )
            drawLine(
                color = when {
                    isQuarterMark -> WatchGold
                    isHourMark -> Color(0xFFCCFBF1)
                    else -> Color(0xFF64748B).copy(alpha = 0.75f)
                },
                start = start,
                end = end,
                strokeWidth = when {
                    isQuarterMark -> 2.4.dp.toPx()
                    isHourMark -> 1.6.dp.toPx()
                    else -> 0.8.dp.toPx()
                },
                cap = StrokeCap.Round
            )
        }

        // Hour hand
        val hourAngle = (hours * 30f - 90f) * (PI / 180f)
        drawLine(
            color = Color.White,
            start = center,
            end = Offset(
                x = center.x + (radius * 0.48f * cos(hourAngle)).toFloat(),
                y = center.y + (radius * 0.48f * sin(hourAngle)).toFloat()
            ),
            strokeWidth = (size.value * 0.045f).coerceAtLeast(2.2f).dp.toPx(),
            cap = StrokeCap.Round
        )

        // Minute hand
        val minuteAngle = (minutes * 6f - 90f) * (PI / 180f)
        drawLine(
            color = Color(0xFF5EEAD4),
            start = center,
            end = Offset(
                x = center.x + (radius * 0.68f * cos(minuteAngle)).toFloat(),
                y = center.y + (radius * 0.68f * sin(minuteAngle)).toFloat()
            ),
            strokeWidth = (size.value * 0.032f).coerceAtLeast(1.6f).dp.toPx(),
            cap = StrokeCap.Round
        )

        // Second hand with counterweight tail
        val secondAngle = (seconds * 6f - 90f) * (PI / 180f)
        val tailStart = Offset(
            x = center.x - (radius * 0.18f * cos(secondAngle)).toFloat(),
            y = center.y - (radius * 0.18f * sin(secondAngle)).toFloat()
        )
        val tipEnd = Offset(
            x = center.x + (radius * 0.78f * cos(secondAngle)).toFloat(),
            y = center.y + (radius * 0.78f * sin(secondAngle)).toFloat()
        )
        drawLine(
            color = WatchSecondHand,
            start = tailStart,
            end = tipEnd,
            strokeWidth = 1.4.dp.toPx(),
            cap = StrokeCap.Round
        )

        // Center jewel cap
        drawCircle(
            color = WatchGold,
            radius = (size.value * 0.055f).coerceAtLeast(3f).dp.toPx(),
            center = center
        )
        drawCircle(
            color = WatchDialDark,
            radius = (size.value * 0.022f).coerceAtLeast(1.3f).dp.toPx(),
            center = center
        )
    }
}
