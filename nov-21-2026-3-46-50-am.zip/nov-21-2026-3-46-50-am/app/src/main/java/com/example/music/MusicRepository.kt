package com.example.music

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class MusicRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    suspend fun searchMusic(query: String, mode: MusicSearchMode): List<MusicTrack> =
        withContext(Dispatchers.IO) {
            val trimmed = query.trim()
            if (trimmed.isEmpty()) return@withContext emptyList()

            coroutineScope {
                val lrclibDeferred = async {
                    if (mode == MusicSearchMode.TITLE_ARTIST) emptyList() else searchLrclib(trimmed)
                }
                val audiusDeferred = async {
                    if (mode == MusicSearchMode.LYRICS) emptyList() else searchAudius(trimmed)
                }
                val deezerDeferred = async {
                    if (mode == MusicSearchMode.LYRICS) emptyList() else searchDeezer(trimmed)
                }
                val itunesDeferred = async {
                    if (mode == MusicSearchMode.LYRICS) emptyList() else searchItunes(trimmed)
                }

                val lrcHits = lrclibDeferred.await()
                val audiusTracks = audiusDeferred.await()
                val deezerTracks = deezerDeferred.await()
                val itunesTracks = itunesDeferred.await()

                val combined = mutableListOf<MusicTrack>()

                // For lyrics hits, resolve audio stream URLs from Audius/Deezer/iTunes
                if (lrcHits.isNotEmpty()) {
                    val resolvedFromLyrics = lrcHits.take(6).map { lrc ->
                        async {
                            val existingMatch = (audiusTracks + deezerTracks + itunesTracks).firstOrNull {
                                it.title.contains(lrc.trackName, ignoreCase = true) &&
                                    it.artist.contains(lrc.artistName, ignoreCase = true)
                            }
                            if (existingMatch != null) {
                                existingMatch.copy(
                                    matchedLyricSnippet = lrc.snippet,
                                    fullLyrics = lrc.plainLyrics
                                )
                            } else {
                                val resolved = resolveAudioForTrack(lrc.trackName, lrc.artistName)
                                resolved?.copy(
                                    matchedLyricSnippet = lrc.snippet,
                                    fullLyrics = lrc.plainLyrics
                                )
                            }
                        }
                    }.mapNotNull { it.await() }
                    combined.addAll(resolvedFromLyrics)
                }

                // Prefer full-length MP3 tracks (Audius), then Deezer MP3s, then iTunes high-res AAC/M4A
                combined.addAll(audiusTracks)
                combined.addAll(deezerTracks)
                combined.addAll(itunesTracks)

                // Deduplicate by normalized title + artist while keeping highest quality / lyric match
                val seen = LinkedHashMap<String, MusicTrack>()
                for (track in combined) {
                    if (track.streamUrl.isBlank()) continue
                    val key = "${track.title.lowercase().trim()}|${track.artist.lowercase().trim()}"
                    val existing = seen[key]
                    if (existing == null) {
                        seen[key] = track
                    } else {
                        val mergedSnippet = existing.matchedLyricSnippet ?: track.matchedLyricSnippet
                        val mergedLyrics = existing.fullLyrics ?: track.fullLyrics
                        val winner = if (track.isFullTrack && !existing.isFullTrack) track else existing
                        seen[key] = winner.copy(
                            matchedLyricSnippet = mergedSnippet,
                            fullLyrics = mergedLyrics
                        )
                    }
                }

                // Rank exact title/artist/lyric matches first, then full-track MP3s
                seen.values.sortedWith(
                    compareByDescending<MusicTrack> { it.matchedLyricSnippet != null }
                        .thenByDescending {
                            it.title.contains(trimmed, ignoreCase = true) ||
                                it.artist.contains(trimmed, ignoreCase = true)
                        }
                        .thenByDescending { it.isFullTrack }
                )
            }
        }

    private suspend fun resolveAudioForTrack(trackName: String, artistName: String): MusicTrack? {
        val searchTerms = "$trackName $artistName"
        val audius = searchAudius(searchTerms, limit = 3).firstOrNull()
        if (audius != null) return audius
        val deezer = searchDeezer(searchTerms, limit = 3).firstOrNull()
        if (deezer != null) return deezer
        return searchItunes(searchTerms, limit = 3).firstOrNull()
    }

    private data class LrcHit(
        val trackName: String,
        val artistName: String,
        val albumName: String,
        val plainLyrics: String?,
        val snippet: String?
    )

    private fun searchLrclib(query: String): List<LrcHit> {
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val req = Request.Builder()
                .url("https://lrclib.net/api/search?q=$encoded")
                .header("User-Agent", "AbzarNegarAndroid/1.0")
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val body = resp.body?.string() ?: return emptyList()
                val arr = JSONArray(body)
                val list = mutableListOf<LrcHit>()
                for (i in 0 until minOf(arr.length(), 10)) {
                    val obj = arr.getJSONObject(i)
                    val track = obj.optString("trackName", obj.optString("name", "")).trim()
                    val artist = obj.optString("artistName", "").trim()
                    val album = obj.optString("albumName", "").trim()
                    val lyrics = obj.optString("plainLyrics", "").takeIf { it.isNotBlank() && it != "null" }
                    if (track.isNotEmpty() && artist.isNotEmpty()) {
                        val snippet = extractMatchingLyricSnippet(lyrics, query)
                        list.add(LrcHit(track, artist, album, lyrics, snippet))
                    }
                }
                list
            }
        } catch (e: Exception) {
            Log.w(TAG, "LRCLIB search error: ${e.message}")
            emptyList()
        }
    }

    private fun extractMatchingLyricSnippet(lyrics: String?, query: String): String? {
        if (lyrics.isNullOrBlank()) return null
        val lines = lyrics.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return null
        val words = query.split(Regex("\\s+")).filter { it.length >= 2 }
        val matchIndex = lines.indexOfFirst { line ->
            line.contains(query, ignoreCase = true) ||
                (words.isNotEmpty() && words.all { w -> line.contains(w, ignoreCase = true) })
        }
        return if (matchIndex >= 0) {
            val from = (matchIndex - 1).coerceAtLeast(0)
            val to = (matchIndex + 1).coerceAtMost(lines.lastIndex)
            lines.subList(from, to + 1).joinToString("\n")
        } else {
            lines.take(2).joinToString("\n")
        }
    }

    private fun searchAudius(query: String, limit: Int = 10): List<MusicTrack> {
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://api.audius.co/v1/tracks/search?query=$encoded&app_name=AbzarNegar"
            val req = Request.Builder()
                .url(url)
                .header("Accept", "application/json")
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val body = resp.body?.string() ?: return emptyList()
                val root = JSONObject(body)
                val data = root.optJSONArray("data") ?: return emptyList()
                val tracks = mutableListOf<MusicTrack>()
                for (i in 0 until minOf(data.length(), limit)) {
                    val obj = data.getJSONObject(i)
                    val id = obj.optString("id", "")
                    val title = obj.optString("title", "").trim()
                    val duration = obj.optInt("duration", 0)
                    val user = obj.optJSONObject("user")
                    val artist = user?.optString("name", "ناشناس")?.trim() ?: "ناشناس"
                    val artworkObj = obj.optJSONObject("artwork")
                    val artwork = artworkObj?.optString("480x480")
                        ?.takeIf { it.isNotBlank() && it != "null" }
                        ?: artworkObj?.optString("150x150")
                            ?.takeIf { it.isNotBlank() && it != "null" }
                    if (id.isNotEmpty() && title.isNotEmpty()) {
                        val streamUrl = "https://api.audius.co/v1/tracks/$id/stream?app_name=AbzarNegar"
                        tracks.add(
                            MusicTrack(
                                id = "audius_$id",
                                title = title,
                                artist = artist,
                                album = obj.optString("genre", "تک‌آهنگ").ifBlank { "تک‌آهنگ" },
                                durationSec = duration,
                                artworkUrl = artwork,
                                streamUrl = streamUrl,
                                downloadUrl = streamUrl,
                                qualityLabel = "MP3 کامل 320kbps",
                                sourceName = "Audius",
                                isFullTrack = true
                            )
                        )
                    }
                }
                tracks
            }
        } catch (e: Exception) {
            Log.w(TAG, "Audius search error: ${e.message}")
            emptyList()
        }
    }

    private fun searchDeezer(query: String, limit: Int = 12): List<MusicTrack> {
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://api.deezer.com/search?q=$encoded&limit=$limit"
            val req = Request.Builder().url(url).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val body = resp.body?.string() ?: return emptyList()
                val root = JSONObject(body)
                val data = root.optJSONArray("data") ?: return emptyList()
                val tracks = mutableListOf<MusicTrack>()
                for (i in 0 until data.length()) {
                    val obj = data.getJSONObject(i)
                    val id = obj.optLong("id", 0L)
                    val title = obj.optString("title", "").trim()
                    val preview = obj.optString("preview", "").trim()
                    val duration = obj.optInt("duration", 30)
                    val artistObj = obj.optJSONObject("artist")
                    val artist = artistObj?.optString("name", "")?.trim() ?: ""
                    val albumObj = obj.optJSONObject("album")
                    val album = albumObj?.optString("title", "")?.trim() ?: ""
                    val cover = albumObj?.optString("cover_big")
                        ?.takeIf { it.isNotBlank() && it != "null" }
                        ?: albumObj?.optString("cover_medium")
                    if (title.isNotEmpty() && preview.startsWith("http")) {
                        tracks.add(
                            MusicTrack(
                                id = "deezer_$id",
                                title = title,
                                artist = artist.ifEmpty { "ناشناس" },
                                album = album.ifEmpty { "تک‌آهنگ" },
                                durationSec = 30,
                                artworkUrl = cover,
                                streamUrl = preview,
                                downloadUrl = preview,
                                qualityLabel = "MP3 باکیفیت (${duration}s)",
                                sourceName = "Deezer MP3",
                                isFullTrack = false
                            )
                        )
                    }
                }
                tracks
            }
        } catch (e: Exception) {
            Log.w(TAG, "Deezer search error: ${e.message}")
            emptyList()
        }
    }

    private fun searchItunes(query: String, limit: Int = 15): List<MusicTrack> {
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://itunes.apple.com/search?term=$encoded&media=music&entity=song&limit=$limit"
            val req = Request.Builder().url(url).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val body = resp.body?.string() ?: return emptyList()
                val root = JSONObject(body)
                val results = root.optJSONArray("results") ?: return emptyList()
                val tracks = mutableListOf<MusicTrack>()
                for (i in 0 until results.length()) {
                    val obj = results.getJSONObject(i)
                    val trackId = obj.optLong("trackId", 0L)
                    val title = obj.optString("trackName", "").trim()
                    val artist = obj.optString("artistName", "").trim()
                    val album = obj.optString("collectionName", "").trim()
                    val previewUrl = obj.optString("previewUrl", "").trim()
                    val artwork100 = obj.optString("artworkUrl100", "").trim()
                    val artworkHigh = if (artwork100.contains("100x100")) {
                        artwork100.replace("100x100", "600x600")
                    } else {
                        artwork100
                    }
                    if (title.isNotEmpty() && previewUrl.startsWith("http")) {
                        tracks.add(
                            MusicTrack(
                                id = "itunes_$trackId",
                                title = title,
                                artist = artist.ifEmpty { "ناشناس" },
                                album = album.ifEmpty { "آلبوم" },
                                durationSec = 30,
                                artworkUrl = artworkHigh.takeIf { it.isNotBlank() },
                                streamUrl = previewUrl,
                                downloadUrl = previewUrl,
                                qualityLabel = "کیفیت بالا (پخش آنلاین و دانلود)",
                                sourceName = "iTunes",
                                isFullTrack = false
                            )
                        )
                    }
                }
                tracks
            }
        } catch (e: Exception) {
            Log.w(TAG, "iTunes search error: ${e.message}")
            emptyList()
        }
    }

    companion object {
        private const val TAG = "MusicRepository"
    }
}
