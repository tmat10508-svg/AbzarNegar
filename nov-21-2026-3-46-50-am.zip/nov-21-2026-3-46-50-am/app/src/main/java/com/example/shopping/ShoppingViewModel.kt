package com.example.shopping

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface ShoppingUiState {
    data object Idle : ShoppingUiState
    data object Loading : ShoppingUiState
    data class Success(
        val query: String,
        val lowestOffer: ProductOffer,
        val otherOffers: List<ProductOffer>,
        val warnings: List<String>
    ) : ShoppingUiState
    data class EmptyOrBlocked(
        val query: String,
        val message: String
    ) : ShoppingUiState
}

class ShoppingViewModel : ViewModel() {

    private val repository = ShoppingRepository()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _uiState = MutableStateFlow<ShoppingUiState>(ShoppingUiState.Idle)
    val uiState: StateFlow<ShoppingUiState> = _uiState.asStateFlow()

    fun updateQuery(newQuery: String) {
        _query.value = newQuery
    }

    fun search(customQuery: String = _query.value) {
        val trimmed = customQuery.trim()
        if (trimmed.isEmpty()) return
        _query.value = trimmed

        viewModelScope.launch {
            _uiState.value = ShoppingUiState.Loading
            try {
                val res = repository.searchLowestPriceInIran(trimmed)
                if (res.offers.isNotEmpty()) {
                    _uiState.value = ShoppingUiState.Success(
                        query = trimmed,
                        lowestOffer = res.offers.first(),
                        otherOffers = res.offers.drop(1),
                        warnings = res.sourceWarnings
                    )
                } else {
                    val reason = if (res.sourceWarnings.isNotEmpty()) {
                        "امکان دریافت مستقیم قیمت‌ها در این شبکه برقرار نشد (${res.sourceWarnings.joinToString("، ")}). می‌توانید مستقیماً کمترین قیمت را در مراجع مقایسه قیمت ایران باز کنید:"
                    } else {
                        "کالای موجودی با این عنوان پیدا نشد. با عنوان دقیق‌تر جستجو کنید یا از لینک‌های مقایسه سراسری زیر استفاده نمایید:"
                    }
                    _uiState.value = ShoppingUiState.EmptyOrBlocked(
                        query = trimmed,
                        message = reason
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.value = ShoppingUiState.EmptyOrBlocked(
                    query = trimmed,
                    message = "خطا در جستجوی کالا: ${e.localizedMessage ?: "اتصال اینترنت را بررسی کنید"}"
                )
            }
        }
    }
}
