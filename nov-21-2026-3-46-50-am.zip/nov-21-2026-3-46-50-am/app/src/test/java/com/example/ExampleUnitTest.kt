package com.example

import com.example.calculator.BigCalculatorEngine
import com.example.util.PersianUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun calculatorSupportsOverFiftyDigitsWithSeparators() {
        val fiftyFiveDigitsA = "1234567890123456789012345678901234567890123456789012345"
        val fiftyFiveDigitsB = "1000000000000000000000000000000000000000000000000000005"
        val result = BigCalculatorEngine.evaluate("$fiftyFiveDigitsA+$fiftyFiveDigitsB")
        assertTrue(result is BigCalculatorEngine.CalcResult.Success)
        val success = result as BigCalculatorEngine.CalcResult.Success
        assertEquals(55, success.digitCount)
        assertEquals(
            "2,234,567,890,123,456,789,012,345,678,901,234,567,890,123,456,789,012,350",
            success.formatted
        )
    }

    @Test
    fun calculatorDivisionProducesOverFiftyDecimalDigits() {
        val result = BigCalculatorEngine.evaluate("1÷3")
        assertTrue(result is BigCalculatorEngine.CalcResult.Success)
        val success = result as BigCalculatorEngine.CalcResult.Success
        assertTrue(success.digitCount >= 60)
        assertTrue(success.formatted.startsWith("0.33333333333333333333333333333333333333333333333333"))
    }

    @Test
    fun jalaliConversionMatchesKnownDate() {
        // 2024-03-20 is 1403-01-01 (Farvardin 1, 1403)
        val (jy, jm, jd) = PersianUtils.gregorianToJalali(2024, 3, 20)
        assertEquals(1403, jy)
        assertEquals(1, jm)
        assertEquals(1, jd)
    }
}
